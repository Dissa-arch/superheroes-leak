# Tips to troubleshooting
1. Make sure all your resources are in lowercase (a, b, c, d, e... **NOT** A, B, C, D, E)
2. Make sure you check your files for any missing commas or typo
3. Make sure what you set for your textures location are correct... **matching location** between what you set in the jsons and the actual location
4. There are not to be **any spaces** in any files/folder, if you want to have spaces, use **underscores** instead

# FAQ
Why is my addon pack not loading?
1. You have a typo somewhere in your addonpack making LC unable to load it.
2. The addonpack.mcmeta file is in a folder which is inside zip file, `zip file/folder/addonpack.mcmeta` which is not WHAT YOU SHOULD BE DOING, **INSTEAD**, `zip file/addonpack.mcmeta`
3. As of LC 2.0.5, addonpacks no longer need to be in zip files, they can be inside folders, `.minecraft/addonpacks/folder/addonpack.mcmeta`.

Why is effects not showing?
1. Oh I don't know, maybe cause you are missing some important stuffs in particular to that effect you are adding! SO READ THE DAMN WIKI WITH BOTH EYES OPEN!
2. Make sure you ain't missing any commas, colons for `"key": value` and closing brackets `[]` and `{}`

Why is my suit not showing?
1. In your suit json, you are probably stating the wrong path to your suit texture, it should be `addonpackID:textures/models/armor/whateverFolder/suitName.png`
2. Your suit texture doesn't match it's path to the one you setin your suit json.

# Terms of usage of resources
**The use of the term, "resources", is defined as any pictures used in this project.**

If you want to use any of the resources in this project in **your** project, you are to credit the creator as defined under **Credits** above.

# Credits

* Sheriff - Flash suit textures
* Spyeedy - Flash item textures